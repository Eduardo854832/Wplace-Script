# Tutorial: How to Use Wplace-AutoFarm

**Attention: Always copy the script directly from the official repository!**

Step-by-step

1. Open Google Chrome.
2. Click the three dots in the top-right corner of the browser.
3. Add any page to your bookmarks (it can be the current one).
4. Click the bookmark confirmation message.
5. Rename the bookmark (example: wplace).
6. Clear the bookmark’s URL field.
7. Paste the script copied from the official repository.
8. Save by clicking the back arrow.
9. Go to wplace.live.
10. Type the bookmark name in the address bar.
11. Click the bookmark to activate the script.

Done! The script will now be active! 🚀

---

Questions? Check the README.EN.md or open an issue.

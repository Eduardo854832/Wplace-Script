(async () => {
  const CONFIG = {
    START_X: 742,
    START_Y: 1148,
    PIXELS_PER_LINE: 100,
    DELAY: 1000,
    THEME: {
      primary: '#F0F2F5',
      secondary: '#FFFFFF',
      accent: '#6C63FF',
      text: '#2D3436',
      highlight: '#8E44AD',
      success: '#2ECC71',
      error: '#E74C3C'
    }
  };

  const state = {
    running: false,
    paintedCount: 0,
    charges: { count: 0, max: 80, cooldownMs: 30000 },
    userInfo: null,
    lastPixel: null,
    minimized: false,
    menuOpen: false,
    language: 'en'
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // Função fetchAPI modificada para retornar o status e os dados da resposta
  const fetchAPI = async (url, options = {}) => {
    try {
      const res = await fetch(url, {
        credentials: 'include',
        ...options
      });
      // Tenta parsear a resposta como JSON. Se falhar, retorna um objeto vazio.
      const data = await res.json().catch(() => ({})); 
      return { status: res.status, data: data };
    } catch (e) {
      // Em caso de erro de rede (ex: sem internet), retorna status 0 e a mensagem de erro
      return { status: 0, error: e.message || "Network Error" };
    }
  };

  const getRandomPosition = () => ({
    x: Math.floor(Math.random() * CONFIG.PIXELS_PER_LINE),
    y: Math.floor(Math.random() * CONFIG.PIXELS_PER_LINE)
  });

  const paintPixel = async (x, y) => {
    const randomColor = Math.floor(Math.random() * 31) + 1;
    return await fetchAPI(`https://backend.wplace.live/s0/pixel/${CONFIG.START_X}/${CONFIG.START_Y}`, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify({ coords: [x, y], colors: [randomColor] })
    });
  };

  const getCharge = async () => {
    const response = await fetchAPI('https://backend.wplace.live/me');
    if (response && response.data) { // Verifica se a resposta e os dados existem
      const data = response.data;
      state.userInfo = data;
      state.charges = {
        count: Math.floor(data.charges.count),
        max: Math.floor(data.charges.max),
        cooldownMs: data.charges.cooldownMs
      };
      if (state.userInfo.level) {
        state.userInfo.level = Math.floor(state.userInfo.level);
      }
    } else {
        // Se getCharge falhar, podemos exibir uma mensagem de erro aqui também
        updateUI(state.language === 'pt' ? `❌ Erro ao obter cargas: ${response.status || response.error}` : `❌ Error getting charges: ${response.status || response.error}`, 'error');
    }
    return state.charges;
  };

  const detectUserLocation = async () => {
    try {
      const response = await fetch('https://ipapi.co/json/');
      const data = await response.json();
      if (data.country === 'BR') {
        state.language = 'pt';
      } else if (data.country === 'US') {
        state.language = 'en';
      } else {
        state.language = 'en';
      }
    } catch {
      state.language = 'en';
    }
  };

  const paintLoop = async () => {
    while (state.running) {
      const { count, cooldownMs } = state.charges;
      
      if (count < 1) {
        updateUI(state.language === 'pt' ? `⏳ Sem cargas. Esperando ${Math.ceil(cooldownMs/1000)}s...` : `⏳ No charges. Waiting ${Math.ceil(cooldownMs/1000)}s...`, 'status');
        await sleep(cooldownMs);
        await getCharge(); // Tenta obter cargas novamente após o cooldown
        continue;
      }

      const randomPos = getRandomPosition();
      const paintResult = await paintPixel(randomPos.x, randomPos.y);
      
      // Verifica se a pintura foi bem-sucedida
      if (paintResult.data?.painted === 1) {
        state.paintedCount++;
        state.lastPixel = { 
          x: CONFIG.START_X + randomPos.x,
          y: CONFIG.START_Y + randomPos.y,
          time: new Date() 
        };
        state.charges.count--;
        
        document.getElementById('paintEffect').style.animation = `pulse 0.5s ${CONFIG.THEME.success}`;
        setTimeout(() => {
          document.getElementById('paintEffect').style.animation = '';
        }, 500);
        
        updateUI(state.language === 'pt' ? '✅ Pixel pintado!' : '✅ Pixel painted!', 'success');
      } else {
        // Lógica para exibir o erro detalhado no UI
        let errorMessage = state.language === 'pt' ? '❌ Falha ao pintar' : '❌ Failed to paint';
        
        if (paintResult.status) { // Se houver um status HTTP (não é erro de rede puro)
            errorMessage += ` (Status: ${paintResult.status}`;
            if (paintResult.data && (paintResult.data.message || paintResult.data.error)) {
                // Tenta pegar a mensagem de erro do JSON de resposta
                errorMessage += `: ${paintResult.data.message || paintResult.data.error}`;
            } else if (paintResult.data && paintResult.data.painted === 0) {
                // Se 'painted' for 0, mas sem mensagem específica
                errorMessage += `: Não permitido pelo servidor`;
            }
            errorMessage += `)`;
        } else if (paintResult.error) { // Se for um erro de rede (status 0)
            errorMessage += ` (Erro de Rede: ${paintResult.error})`;
        } else {
            // Caso genérico, se não houver status nem erro explícito
            errorMessage += ` (Resposta desconhecida)`;
        }
        updateUI(errorMessage, 'error');
      }

      await sleep(CONFIG.DELAY);
      updateStats();
    }
  };

  const createUI = () => {
    if (state.menuOpen) {
      console.log('Menu já está aberto. Não recriando a UI.');
      return; 
    }
    state.menuOpen = true;

    const fontAwesome = document.createElement('link');
    fontAwesome.rel = 'stylesheet';
    fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
    document.head.appendChild(fontAwesome);

    const style = document.createElement('style');
    style.textContent = `
      @keyframes pulse {
        0% { box-shadow: 0 0 0 0 rgba(${parseInt(CONFIG.THEME.success.slice(1,3), 16)}, ${parseInt(CONFIG.THEME.success.slice(3,5), 16)}, ${parseInt(CONFIG.THEME.success.slice(5,7), 16)}, 0.7); }
        70% { box-shadow: 0 0 0 10px rgba(${parseInt(CONFIG.THEME.success.slice(1,3), 16)}, ${parseInt(CONFIG.THEME.success.slice(3,5), 16)}, ${parseInt(CONFIG.THEME.success.slice(5,7), 16)}, 0); }
        100% { box-shadow: 0 0 0 0 rgba(${parseInt(CONFIG.THEME.success.slice(1,3), 16)}, ${parseInt(CONFIG.THEME.success.slice(3,5), 16)}, ${parseInt(CONFIG.THEME.success.slice(5,7), 16)}, 0); }
      }
      @keyframes slideIn {
        from { transform: translateY(20px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }

      .wplace-bot-panel {
        position: fixed;
        top: 20px;
        right: 20px;
        width: 300px;
        background: ${CONFIG.THEME.primary};
        border: none;
        border-radius: 16px;
        padding: 0;
        box-shadow: 0 6px 15px rgba(0,0,0,0.1);
        z-index: 9999;
        font-family: 'Inter', 'Segoe UI', Roboto, sans-serif;
        color: ${CONFIG.THEME.text};
        animation: slideIn 0.4s ease-out;
        overflow: hidden;
        transition: all 0.3s ease;
      }
      .wplace-bot-panel.minimized {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        overflow: hidden;
        display: flex;
        justify-content: center;
        align-items: center;
        box-shadow: 0 4px 10px rgba(0,0,0,0.15);
      }
      .wplace-bot-panel.minimized .wplace-header-title {
        display: none;
      }
      .wplace-bot-panel.minimized .wplace-header-controls {
        width: 100%;
        justify-content: center;
      }
      .wplace-bot-panel.minimized .wplace-header-btn {
        font-size: 24px;
      }

      .wplace-header {
        padding: 15px 20px;
        background: ${CONFIG.THEME.secondary};
        color: ${CONFIG.THEME.highlight};
        font-size: 18px;
        font-weight: 700;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: grab;
        user-select: none;
        border-bottom: 1px solid rgba(0,0,0,0.05);
      }
      .wplace-header-title {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .wplace-header-controls {
        display: flex;
        gap: 15px;
      }
      .wplace-header-btn {
        background: none;
        border: none;
        color: ${CONFIG.THEME.text};
        cursor: pointer;
        opacity: 0.6;
        transition: opacity 0.2s, transform 0.2s;
        font-size: 18px;
      }
      .wplace-header-btn:hover {
        opacity: 1;
        transform: scale(1.1);
      }

      .wplace-content {
        padding: 20px;
        display: ${state.minimized ? 'none' : 'block'};
      }

      .wplace-controls {
        display: flex;
        gap: 15px;
        margin-bottom: 25px;
      }
      .wplace-btn {
        flex: 1;
        padding: 14px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        transition: all 0.2s ease;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      }
      .wplace-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
      }
      .wplace-btn-primary {
        background: ${CONFIG.THEME.accent};
        color: ${CONFIG.THEME.text};
      }
      .wplace-btn-stop {
        background: ${CONFIG.THEME.error};
        color: ${CONFIG.THEME.text};
      }

      .wplace-stats {
        background: ${CONFIG.THEME.secondary};
        padding: 18px;
        border-radius: 12px;
        margin-bottom: 25px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
      }
      .wplace-stat-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        font-size: 15px;
        border-bottom: 1px solid rgba(0,0,0,0.05);
      }
      .wplace-stat-item:last-child {
        border-bottom: none;
      }
      .wplace-stat-label {
        display: flex;
        align-items: center;
        gap: 10px;
        opacity: 0.8;
        font-weight: 500;
      }
      .wplace-stat-item i {
        color: ${CONFIG.THEME.highlight};
        font-size: 16px;
      }

      .wplace-status {
        padding: 12px;
        border-radius: 8px;
        text-align: center;
        font-size: 14px;
        font-weight: 600;
        transition: background 0.3s, color 0.3s;
      }
      .status-default {
        background: rgba(${parseInt(CONFIG.THEME.text.slice(1,3), 16)}, ${parseInt(CONFIG.THEME.text.slice(3,5), 16)}, ${parseInt(CONFIG.THEME.text.slice(5,7), 16)}, 0.05);
        color: ${CONFIG.THEME.text};
      }
      .status-success {
        background: rgba(${parseInt(CONFIG.THEME.success.slice(1,3), 16)}, ${parseInt(CONFIG.THEME.success.slice(3,5), 16)}, ${parseInt(CONFIG.THEME.success.slice(5,7), 16)}, 0.1);
        color: ${CONFIG.THEME.success};
      }
      .status-error {
        background: rgba(${parseInt(CONFIG.THEME.error.slice(1,3), 16)}, ${parseInt(CONFIG.THEME.error.slice(3,5), 16)}, ${parseInt(CONFIG.THEME.error.slice(5,7), 16)}, 0.1);
        color: ${CONFIG.THEME.error};
      }

      #paintEffect {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        border-radius: 16px;
      }
    `;
    document.head.appendChild(style);

    const translations = {
      pt: {
        title: "WPlace Auto-Farm",
        start: "Iniciar",
        stop: "Parar",
        ready: "Pronto para começar",
        user: "Usuário",
        pixels: "Pixels",
        charges: "Cargas",
        level: "Nível",
        close: "Fechar"
      },
      en: {
        title: "WPlace Auto-Farm",
        start: "Start",
        stop: "Stop",
        ready: "Ready to start",
        user: "User",
        pixels: "Pixels",
        charges: "Charges",
        level: "Level",
        close: "Close"
      }
    };

    const t = translations[state.language] || translations.en;

    const panel = document.createElement('div');
    panel.className = 'wplace-bot-panel';
    panel.innerHTML = `
      <div id="paintEffect"></div>
      <div class="wplace-header">
        <div class="wplace-header-title">
          <i class="fas fa-robot"></i>
          <span>${t.title}</span>
        </div>
        <div class="wplace-header-controls">
          <button id="minimizeBtn" class="wplace-header-btn" title="${state.language === 'pt' ? 'Minimizar' : 'Minimize'}">
            <i class="fas fa-${state.minimized ? 'circle-plus' : 'minus'}"></i>
          </button>
          <button id="closeBtn" class="wplace-header-btn" title="${t.close}">
            <i class="fas fa-times-circle"></i>
          </button>
        </div>
      </div>
      <div class="wplace-content">
        <div class="wplace-controls">
          <button id="toggleBtn" class="wplace-btn wplace-btn-primary">
            <i class="fas fa-play-circle"></i>
            <span>${t.start}</span>
          </button>
        </div>
        
        <div class="wplace-stats">
          <div id="statsArea">
            <div class="wplace-stat-item">
              <div class="wplace-stat-label"><i class="fas fa-spinner fa-spin"></i> ${state.language === 'pt' ? 'Carregando...' : 'Loading...'}</div>
            </div>
          </div>
        </div>
        
        <div id="statusText" class="wplace-status status-default">
          ${t.ready}
        </div>
      </div>
    `;
    
    document.body.appendChild(panel);
    
    const header = panel.querySelector('.wplace-header');
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    
    header.onmousedown = dragMouseDown;
    
    function dragMouseDown(e) {
      if (e.target.closest('.wplace-header-btn')) return;
      
      e = e || window.event;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
    }
    
    function elementDrag(e) {
      e = e || window.event;
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;
      panel.style.top = (panel.offsetTop - pos2) + "px";
      panel.style.left = (panel.offsetLeft - pos1) + "px";
    }
    
    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
    }
    
    const toggleBtn = panel.querySelector('#toggleBtn');
    const minimizeBtn = panel.querySelector('#minimizeBtn');
    const closeBtn = panel.querySelector('#closeBtn');
    const statusText = panel.querySelector('#statusText');
    const content = panel.querySelector('.wplace-content');
    const statsArea = panel.querySelector('#statsArea');
    
    toggleBtn.addEventListener('click', () => {
      state.running = !state.running;
      
      if (state.running) {
        toggleBtn.innerHTML = `<i class="fas fa-pause-circle"></i> <span>${t.stop}</span>`;
        toggleBtn.classList.remove('wplace-btn-primary');
        toggleBtn.classList.add('wplace-btn-stop');
        updateUI(state.language === 'pt' ? '▶️ Pintura iniciada!' : '▶️ Painting started!', 'success');
        paintLoop();
      } else {
        toggleBtn.innerHTML = `<i class="fas fa-play-circle"></i> <span>${t.start}</span>`;
        toggleBtn.classList.add('wplace-btn-primary');
        toggleBtn.classList.remove('wplace-btn-stop');
        updateUI(state.language === 'pt' ? '⏸️ Pintura pausada' : '⏸️ Painting paused', 'default');
      }
    });
    
    minimizeBtn.addEventListener('click', () => {
      state.minimized = !state.minimized;
      content.style.display = state.minimized ? 'none' : 'block';
      minimizeBtn.innerHTML = `<i class="fas fa-${state.minimized ? 'circle-plus' : 'minus'}"></i>`;
      panel.classList.toggle('minimized', state.minimized);
    });

    closeBtn.addEventListener('click', () => {
      state.running = false;
      if (panel.parentNode) {
        panel.parentNode.removeChild(panel);
      }
      state.menuOpen = false;
      console.log('Menu fechado. Pode ser reaberto executando o script novamente.');
    });
    
    window.addEventListener('beforeunload', () => {
      state.menuOpen = false;
    });
  };

  window.updateUI = (message, type = 'default') => {
    const statusText = document.querySelector('#statusText');
    if (statusText) {
      statusText.textContent = message;
      statusText.className = `wplace-status status-${type}`;
      statusText.style.animation = 'none';
      void statusText.offsetWidth;
      statusText.style.animation = 'slideIn 0.3s ease-out';
    }
  };

  window.updateStats = async () => {
    await getCharge();
    const statsArea = document.querySelector('#statsArea');
    if (statsArea) {
      const t = {
        pt: {
          user: "Usuário",
          pixels: "Pixels",
          charges: "Cargas",
          level: "Nível"
        },
        en: {
          user: "User",
          pixels: "Pixels",
          charges: "Charges",
          level: "Level"
        }
      }[state.language] || {
        user: "User",
        pixels: "Pixels",
        charges: "Charges",
        level: "Level"
      };

      statsArea.innerHTML = `
        <div class="wplace-stat-item">
          <div class="wplace-stat-label"><i class="fas fa-user-astronaut"></i> ${t.user}</div>
          <div>${state.userInfo.name}</div>
        </div>
        <div class="wplace-stat-item">
          <div class="wplace-stat-label"><i class="fas fa-brush"></i> ${t.pixels}</div>
          <div>${state.paintedCount}</div>
        </div>
        <div class="wplace-stat-item">
          <div class="wplace-stat-label"><i class="fas fa-charging-station"></i> ${t.charges}</div>
          <div>${Math.floor(state.charges.count)}/${Math.floor(state.charges.max)}</div>
        </div>
        <div class="wplace-stat-item">
          <div class="wplace-stat-label"><i class="fas fa-award"></i> ${t.level}</div>
          <div>${state.userInfo?.level || '0'}</div>
        </div>
      `;
    }
  };

  await detectUserLocation();
  createUI();
  await getCharge();
  updateStats();
})();

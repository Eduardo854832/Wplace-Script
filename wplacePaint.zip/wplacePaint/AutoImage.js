
(async () => {
  // ========================================
  // WPLACE AUTO PAINTER V2.0 - NEON EDITION
  // Design: Cyberpunk/Neon Theme
  // Funcionalidades Extras: Múltiplas imagens, salvamento de progresso, estatísticas avançadas
  // ========================================

  const CONFIG = {
    VERSION: "2.0.0",
    COOLDOWN_DEFAULT: 31000,
    TRANSPARENCY_THRESHOLD: 100,
    WHITE_THRESHOLD: 250,
    LOG_INTERVAL: 5,
    AUTO_SAVE_INTERVAL: 30000, // Salva progresso a cada 30s
    MAX_QUEUE_SIZE: 10,
    THEME: {
      primary: '#0a0a0a',
      secondary: '#1a1a2e',
      tertiary: '#16213e',
      accent: '#0f3460',
      neon_cyan: '#00ffff',
      neon_pink: '#ff00ff',
      neon_green: '#00ff41',
      neon_orange: '#ff8c00',
      neon_purple: '#bf00ff',
      text_primary: '#ffffff',
      text_secondary: '#b0b0b0',
      text_muted: '#666666',
      error: '#ff073a',
      warning: '#ffab00',
      success: '#00ff41',
      glass: 'rgba(255, 255, 255, 0.1)'
    }
  };

  const LANGUAGES = {
    pt: {
      title: "WPlace Auto Painter V2",
      subtitle: "NEON EDITION",
      initBot: "INICIALIZAR SISTEMA",
      uploadImages: "CARREGAR IMAGENS",
      imageQueue: "FILA DE IMAGENS",
      projectSettings: "CONFIGURAÇÕES",
      startProject: "INICIAR PROJETO",
      pauseProject: "PAUSAR PROJETO",
      stopProject: "PARAR PROJETO",
      saveProgress: "SALVAR PROGRESSO",
      loadProgress: "CARREGAR PROGRESSO",
      statistics: "ESTATÍSTICAS",
      advanced: "AVANÇADO",
      // Status messages
      systemReady: "🚀 Sistema pronto para operação",
      checkingColors: "🔍 Analisando paleta de cores...",
      colorsFound: "✅ {count} cores disponíveis detectadas",
      noColorsFound: "❌ Paleta não encontrada! Abra as cores no site",
      imagesLoaded: "✅ {count} imagem(ns) carregada(s) na fila",
      selectPosition: "👆 Pinte um pixel de referência no canvas",
      positionSet: "✅ Posição inicial configurada",
      projectStarted: "🎨 Projeto iniciado - Modo automático ativo",
      projectPaused: "⏸️ Projeto pausado na posição X:{x} Y:{y}",
      projectStopped: "⏹️ Projeto interrompido pelo usuário",
      projectCompleted: "🎉 Projeto finalizado! {pixels} pixels pintados",
      progressSaved: "💾 Progresso salvo automaticamente",
      // UI Elements
      currentImage: "Imagem Atual",
      queuePosition: "Posição na Fila",
      totalPixels: "Total de Pixels",
      paintedPixels: "Pixels Pintados",
      remainingPixels: "Pixels Restantes",
      charges: "Cargas",
      estimatedTime: "Tempo Estimado",
      pixelsPerMinute: "Pixels/Min",
      efficiency: "Eficiência",
      uptime: "Tempo Ativo",
      // Settings
      autoMode: "Modo Automático",
      smartQueue: "Fila Inteligente",
      autoRestart: "Reinício Automático",
      lowLatency: "Baixa Latência",
      colorOptimization: "Otimização de Cores",
      pixelDelay: "Delay entre Pixels (ms)",
      queueSettings: "Configurações da Fila",
      performanceMode: "Modo Performance"
    },
    en: {
      title: "WPlace Auto Painter V2",
      subtitle: "NEON EDITION",
      initBot: "INITIALIZE SYSTEM",
      uploadImages: "UPLOAD IMAGES",
      imageQueue: "IMAGE QUEUE",
      projectSettings: "PROJECT SETTINGS",
      startProject: "START PROJECT",
      pauseProject: "PAUSE PROJECT",
      stopProject: "STOP PROJECT",
      saveProgress: "SAVE PROGRESS",
      loadProgress: "LOAD PROGRESS",
      statistics: "STATISTICS",
      advanced: "ADVANCED",
      // Status messages
      systemReady: "🚀 System ready for operation",
      checkingColors: "🔍 Analyzing color palette...",
      colorsFound: "✅ {count} available colors detected",
      noColorsFound: "❌ Palette not found! Open colors on site",
      imagesLoaded: "✅ {count} image(s) loaded in queue",
      selectPosition: "👆 Paint a reference pixel on canvas",
      positionSet: "✅ Initial position configured",
      projectStarted: "🎨 Project started - Auto mode active",
      projectPaused: "⏸️ Project paused at position X:{x} Y:{y}",
      projectStopped: "⏹️ Project stopped by user",
      projectCompleted: "🎉 Project completed! {pixels} pixels painted",
      progressSaved: "💾 Progress auto-saved",
      // UI Elements
      currentImage: "Current Image",
      queuePosition: "Queue Position",
      totalPixels: "Total Pixels",
      paintedPixels: "Painted Pixels",
      remainingPixels: "Remaining Pixels",
      charges: "Charges",
      estimatedTime: "Estimated Time",
      pixelsPerMinute: "Pixels/Min",
      efficiency: "Efficiency",
      uptime: "Uptime",
      // Settings
      autoMode: "Auto Mode",
      smartQueue: "Smart Queue",
      autoRestart: "Auto Restart",
      lowLatency: "Low Latency",
      colorOptimization: "Color Optimization",
      pixelDelay: "Pixel Delay (ms)",
      queueSettings: "Queue Settings",
      performanceMode: "Performance Mode"
    }
  };

  // Estado global aprimorado
  const state = {
    version: CONFIG.VERSION,
    initialized: false,
    running: false,
    paused: false,
    language: 'pt',
    
    // Sistema de cores
    availableColors: [],
    colorStats: new Map(),
    
    // Fila de imagens
    imageQueue: [],
    currentImageIndex: 0,
    
    // Posicionamento e região
    startPosition: null,
    region: null,
    currentPosition: { x: 0, y: 0 },
    
    // Estatísticas avançadas
    stats: {
      totalPixelsPainted: 0,
      startTime: null,
      paintingTime: 0,
      averagePixelsPerMinute: 0,
      efficiency: 0,
      errors: 0,
      retries: 0,
      colorChanges: 0
    },
    
    // Configurações
    settings: {
      autoMode: true,
      smartQueue: true,
      autoRestart: false,
      lowLatency: false,
      colorOptimization: true,
      pixelDelay: 100,
      performanceMode: false,
      autoSave: true
    },
    
    // Controle
    charges: 0,
    cooldown: CONFIG.COOLDOWN_DEFAULT,
    lastSave: Date.now(),
    errors: []
  };

  // Utilitários aprimorados
  const Utils = {
    sleep: ms => new Promise(r => setTimeout(r, ms)),
    
    // Distância de cores aprimorada com peso
    colorDistance: (a, b) => {
      const rWeight = 0.3;
      const gWeight = 0.59;
      const bWeight = 0.11;
      return Math.sqrt(
        rWeight * Math.pow(a[0] - b[0], 2) + 
        gWeight * Math.pow(a[1] - b[1], 2) + 
        bWeight * Math.pow(a[2] - b[2], 2)
      );
    },
    
    // Gerador de IDs únicos
    generateId: () => Date.now().toString(36) + Math.random().toString(36).substr(2),
    
    // Formatação de tempo aprimorada
    formatTime: ms => {
      if (ms < 1000) return `${ms}ms`;
      const seconds = Math.floor((ms / 1000) % 60);
      const minutes = Math.floor((ms / (1000 * 60)) % 60);
      const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
      const days = Math.floor(ms / (1000 * 60 * 60 * 24));
      
      let result = '';
      if (days > 0) result += `${days}d `;
      if (hours > 0 || days > 0) result += `${hours}h `;
      if (minutes > 0 || hours > 0 || days > 0) result += `${minutes}m `;
      result += `${seconds}s`;
      return result;
    },
    
    // Notificações toast aprimoradas
    showToast: (message, type = 'info', duration = 4000) => {
      const toastContainer = document.getElementById('toast-container') || (() => {
        const container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = `
          position: fixed;
          top: 20px;
          right: 20px;
          z-index: 10000;
          display: flex;
          flex-direction: column;
          gap: 10px;
        `;
        document.body.appendChild(container);
        return container;
      })();
      
      const toast = document.createElement('div');
      const colors = {
        info: CONFIG.THEME.neon_cyan,
        success: CONFIG.THEME.neon_green,
        warning: CONFIG.THEME.neon_orange,
        error: CONFIG.THEME.error
      };
      
      toast.style.cssText = `
        background: ${CONFIG.THEME.primary};
        border: 2px solid ${colors[type]};
        border-radius: 8px;
        padding: 15px 20px;
        color: ${CONFIG.THEME.text_primary};
        box-shadow: 0 0 20px ${colors[type]}40;
        backdrop-filter: blur(10px);
        animation: slideInRight 0.3s ease-out;
        max-width: 300px;
        word-wrap: break-word;
      `;
      
      toast.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
          <div style="width: 3px; height: 20px; background: ${colors[type]}; border-radius: 2px;"></div>
          <span>${message}</span>
        </div>
      `;
      
      toastContainer.appendChild(toast);
      
      setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease-in forwards';
        setTimeout(() => toast.remove(), 300);
      }, duration);
    },
    
    // Upload múltiplo de imagens
    createMultiImageUploader: () => new Promise(resolve => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/png,image/jpeg,image/gif,image/webp';
      input.multiple = true;
      input.onchange = async () => {
        const files = Array.from(input.files);
        const results = [];
        
        for (const file of files) {
          const fr = new FileReader();
          const result = await new Promise(res => {
            fr.onload = () => res({
              name: file.name,
              size: file.size,
              type: file.type,
              data: fr.result,
              id: Utils.generateId()
            });
            fr.readAsDataURL(file);
          });
          results.push(result);
        }
        
        resolve(results);
      };
      input.click();
    }),
    
    // Extração de cores com cache
    extractAvailableColors: () => {
      const colorElements = document.querySelectorAll('[id^="color-"]');
      const colors = Array.from(colorElements)
        .filter(el => !el.querySelector('svg'))
        .filter(el => {
          const id = parseInt(el.id.replace('color-', ''));
          return id !== 0 && id !== 5; // Exclui cores específicas
        })
        .map(el => {
          const id = parseInt(el.id.replace('color-', ''));
          const rgbStr = el.style.backgroundColor.match(/\d+/g);
          const rgb = rgbStr ? rgbStr.map(Number) : [0, 0, 0];
          return { id, rgb, hex: Utils.rgbToHex(rgb) };
        });
      
      // Atualiza estatísticas de cores
      colors.forEach(color => {
        if (!state.colorStats.has(color.id)) {
          state.colorStats.set(color.id, { used: 0, rgb: color.rgb, hex: color.hex });
        }
      });
      
      return colors;
    },
    
    // Conversão RGB para HEX
    rgbToHex: rgb => '#' + rgb.map(x => x.toString(16).padStart(2, '0')).join(''),
    
    // Detecção de idioma
    detectLanguage: () => {
      const userLang = navigator.language.split('-')[0];
      return LANGUAGES[userLang] ? userLang : 'en';
    },
    
    // Tradução
    t: (key, params = {}) => {
      let text = LANGUAGES[state.language]?.[key] || LANGUAGES.en[key] || key;
      for (const [k, v] of Object.entries(params)) {
        text = text.replace(new RegExp(`{${k}}`, 'g'), v);
      }
      return text;
    },
    
    // Sistema de salvamento/carregamento
    saveProgress: () => {
      const progressData = {
        version: state.version,
        timestamp: Date.now(),
        imageQueue: state.imageQueue,
        currentImageIndex: state.currentImageIndex,
        currentPosition: state.currentPosition,
        startPosition: state.startPosition,
        region: state.region,
        stats: state.stats,
        settings: state.settings
      };
      
      localStorage.setItem('wplace_auto_painter_v2', JSON.stringify(progressData));
      Utils.showToast(Utils.t('progressSaved'), 'success');
    },
    
    loadProgress: () => {
      try {
        const saved = localStorage.getItem('wplace_auto_painter_v2');
        if (!saved) return false;
        
        const progressData = JSON.parse(saved);
        if (progressData.version !== state.version) return false;
        
        // Restaura estado
        Object.assign(state, progressData);
        return true;
      } catch {
        return false;
      }
    }
  };

  // Serviços WPlace aprimorados
  const WPlaceService = {
    async paintPixelInRegion(regionX, regionY, pixelX, pixelY, colorId) {
      try {
        const startTime = Date.now();
        
        const res = await fetch(`https://backend.wplace.live/s0/pixel/${regionX}/${regionY}`, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
          credentials: 'include',
          body: JSON.stringify({ coords: [pixelX, pixelY], colors: [colorId] })
        });
        
        const data = await res.json();
        const success = data?.painted === 1;
        
        // Atualiza estatísticas
        const paintTime = Date.now() - startTime;
        if (success) {
          state.stats.totalPixelsPainted++;
          state.colorStats.get(colorId).used++;
        } else {
          state.stats.errors++;
        }
        
        return success;
      } catch (error) {
        state.stats.errors++;
        state.errors.push({ timestamp: Date.now(), error: error.message });
        return false;
      }
    },
    
    async getCharges() {
      try {
        const res = await fetch('https://backend.wplace.live/me', { 
          credentials: 'include' 
        });
        const data = await res.json();
        return { 
          charges: Math.floor(data.charges?.count || 0), 
          cooldown: data.charges?.cooldownMs || CONFIG.COOLDOWN_DEFAULT 
        };
      } catch {
        return { charges: 0, cooldown: CONFIG.COOLDOWN_DEFAULT };
      }
    }
  };

  // Processador de imagens aprimorado
  class ImageProcessor {
    constructor(imageData) {
      this.imageData = imageData;
      this.canvas = document.createElement('canvas');
      this.ctx = this.canvas.getContext('2d');
      this.img = new Image();
      this.processed = false;
      this.pixels = null;
      this.validPixels = [];
    }
    
    async load() {
      return new Promise((resolve, reject) => {
        this.img.onload = () => {
          this.canvas.width = this.img.width;
          this.canvas.height = this.img.height;
          this.ctx.drawImage(this.img, 0, 0);
          this.processPixels();
          resolve(this);
        };
        this.img.onerror = reject;
        this.img.src = this.imageData.data;
      });
    }
    
    processPixels() {
      const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
      this.pixels = imageData.data;
      this.validPixels = [];
      
      for (let y = 0; y < this.canvas.height; y++) {
        for (let x = 0; x < this.canvas.width; x++) {
          const idx = (y * this.canvas.width + x) * 4;
          const r = this.pixels[idx];
          const g = this.pixels[idx + 1];
          const b = this.pixels[idx + 2];
          const alpha = this.pixels[idx + 3];
          
          // Pula pixels transparentes e brancos
          if (alpha < CONFIG.TRANSPARENCY_THRESHOLD) continue;
          if (r >= CONFIG.WHITE_THRESHOLD && g >= CONFIG.WHITE_THRESHOLD && b >= CONFIG.WHITE_THRESHOLD) continue;
          
          this.validPixels.push({
            x, y, rgb: [r, g, b],
            colorId: null // Será calculado depois
          });
        }
      }
      
      this.processed = true;
    }
    
    getDimensions() {
      return { width: this.canvas.width, height: this.canvas.height };
    }
    
    getValidPixelsCount() {
      return this.validPixels.length;
    }
    
    generateThumbnail(size = 64) {
      const thumbCanvas = document.createElement('canvas');
      thumbCanvas.width = size;
      thumbCanvas.height = size;
      const thumbCtx = thumbCanvas.getContext('2d');
      
      // Calcula dimensões mantendo aspecto
      const { width, height } = this.getDimensions();
      const aspectRatio = width / height;
      let drawWidth = size;
      let drawHeight = size;
      
      if (aspectRatio > 1) {
        drawHeight = size / aspectRatio;
      } else {
        drawWidth = size * aspectRatio;
      }
      
      const offsetX = (size - drawWidth) / 2;
      const offsetY = (size - drawHeight) / 2;
      
      thumbCtx.imageSmoothingEnabled = false;
      thumbCtx.drawImage(this.img, offsetX, offsetY, drawWidth, drawHeight);
      
      return thumbCanvas.toDataURL();
    }
  }

  // UI Manager com design neon/cyberpunk
  class UIManager {
    constructor() {
      this.container = null;
      this.panels = {};
      this.animations = new Set();
    }
    
    async initialize() {
      this.createStyles();
      this.createMainContainer();
      this.createPanels();
      this.bindEvents();
      this.startAnimationLoop();
    }
    
    createStyles() {
      const style = document.createElement('style');
      style.textContent = `
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap');
        
        /* Animações */
        @keyframes neonGlow {
          0%, 100% { text-shadow: 0 0 5px currentColor, 0 0 10px currentColor, 0 0 15px currentColor; }
          50% { text-shadow: 0 0 10px currentColor, 0 0 20px currentColor, 0 0 30px currentColor; }
        }
        
        @keyframes slideInRight {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOutRight {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
        
        @keyframes pulseNeon {
          0%, 100% { box-shadow: 0 0 5px currentColor; }
          50% { box-shadow: 0 0 20px currentColor; }
        }
        
        @keyframes matrixRain {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100vh); }
        }
        
        /* Container principal */
        #wplace-auto-painter-v2 {
          position: fixed;
          top: 20px;
          right: 20px;
          width: 380px;
          background: linear-gradient(135deg, ${CONFIG.THEME.primary}95 0%, ${CONFIG.THEME.secondary}95 100%);
          border: 2px solid ${CONFIG.THEME.neon_cyan};
          border-radius: 12px;
          backdrop-filter: blur(20px);
          box-shadow: 
            0 0 30px ${CONFIG.THEME.neon_cyan}40,
            inset 0 0 30px ${CONFIG.THEME.glass};
          z-index: 9999;
          font-family: 'Orbitron', monospace;
          color: ${CONFIG.THEME.text_primary};
          overflow: hidden;
          animation: slideInRight 0.5s ease-out;
        }
        
        /* Header com efeito neon */
        .painter-header {
          background: linear-gradient(90deg, ${CONFIG.THEME.neon_cyan}20 0%, ${CONFIG.THEME.neon_purple}20 100%);
          padding: 15px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          cursor: move;
          user-select: none;
          border-bottom: 1px solid ${CONFIG.THEME.neon_cyan}60;
        }
        
        .painter-title {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        
        .painter-title h1 {
          margin: 0;
          font-size: 16px;
          font-weight: 900;
          color: ${CONFIG.THEME.neon_cyan};
          animation: neonGlow 2s infinite;
        }
        
        .painter-subtitle {
          font-size: 10px;
          font-weight: 400;
          color: ${CONFIG.THEME.neon_pink};
          letter-spacing: 2px;
        }
        
        .header-controls {
          display: flex;
          gap: 10px;
        }
        
        .header-btn {
          background: none;
          border: 1px solid ${CONFIG.THEME.neon_cyan}60;
          color: ${CONFIG.THEME.neon_cyan};
          width: 30px;
          height: 30px;
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.3s;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .header-btn:hover {
          background: ${CONFIG.THEME.neon_cyan}20;
          box-shadow: 0 0 10px ${CONFIG.THEME.neon_cyan}60;
        }
        
        /* Navegação por tabs */
        .painter-nav {
          display: flex;
          background: ${CONFIG.THEME.secondary}80;
          border-bottom: 1px solid ${CONFIG.THEME.accent};
        }
        
        .nav-tab {
          flex: 1;
          padding: 12px 8px;
          text-align: center;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 1px;
          cursor: pointer;
          background: none;
          border: none;
          color: ${CONFIG.THEME.text_secondary};
          transition: all 0.3s;
          position: relative;
        }
        
        .nav-tab:hover {
          color: ${CONFIG.THEME.neon_cyan};
          background: ${CONFIG.THEME.neon_cyan}10;
        }
        
        .nav-tab.active {
          color: ${CONFIG.THEME.neon_cyan};
          background: ${CONFIG.THEME.neon_cyan}15;
        }
        
        .nav-tab.active::after {
          content: '';
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          height: 2px;
          background: ${CONFIG.THEME.neon_cyan};
          box-shadow: 0 0 10px ${CONFIG.THEME.neon_cyan};
        }
        
        /* Painéis de conteúdo */
        .painter-content {
          height: 500px;
          overflow-y: auto;
          overflow-x: hidden;
        }
        
        .content-panel {
          display: none;
          padding: 20px;
          animation: slideInRight 0.3s ease-out;
        }
        
        .content-panel.active {
          display: block;
        }
        
        /* Botões neon */
        .neon-btn {
          width: 100%;
          padding: 12px 16px;
          margin: 8px 0;
          background: linear-gradient(135deg, ${CONFIG.THEME.secondary} 0%, ${CONFIG.THEME.accent} 100%);
          border: 1px solid currentColor;
          border-radius: 8px;
          color: ${CONFIG.THEME.text_primary};
          font-family: 'Orbitron', monospace;
          font-weight: 700;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 1px;
          cursor: pointer;
          transition: all 0.3s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          position: relative;
          overflow: hidden;
        }
        
        .neon-btn::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, ${CONFIG.THEME.glass}, transparent);
          transition: left 0.5s;
        }
        
        .neon-btn:hover::before {
          left: 100%;
        }
        
        .neon-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 5px 15px currentColor40;
        }
        
        .neon-btn.primary { border-color: ${CONFIG.THEME.neon_cyan}; color: ${CONFIG.THEME.neon_cyan}; }
        .neon-btn.success { border-color: ${CONFIG.THEME.neon_green}; color: ${CONFIG.THEME.neon_green}; }
        .neon-btn.warning { border-color: ${CONFIG.THEME.neon_orange}; color: ${CONFIG.THEME.neon_orange}; }
        .neon-btn.danger { border-color: ${CONFIG.THEME.error}; color: ${CONFIG.THEME.error}; }
        .neon-btn.purple { border-color: ${CONFIG.THEME.neon_purple}; color: ${CONFIG.THEME.neon_purple}; }
        
        .neon-btn:disabled {
          opacity: 0.4;
          cursor: not-allowed;
          transform: none !important;
        }
        
        /* Cards e painéis */
        .neon-card {
          background: linear-gradient(135deg, ${CONFIG.THEME.glass} 0%, ${CONFIG.THEME.secondary}40 100%);
          border: 1px solid ${CONFIG.THEME.accent};
          border-radius: 8px;
          padding: 15px;
          margin: 10px 0;
          backdrop-filter: blur(10px);
        }
        
        .neon-card.glow {
          box-shadow: 0 0 20px ${CONFIG.THEME.neon_cyan}20;
        }
        
        /* Status display */
        .status-display {
          text-align: center;
          padding: 15px;
          border-radius: 8px;
          margin: 10px 0;
          font-size: 13px;
          font-weight: 600;
          border: 1px solid currentColor;
        }
        
        .status-ready { background: ${CONFIG.THEME.neon_green}10; color: ${CONFIG.THEME.neon_green}; }
        .status-working { background: ${CONFIG.THEME.neon_cyan}10; color: ${CONFIG.THEME.neon_cyan}; }
        .status-paused { background: ${CONFIG.THEME.neon_orange}10; color: ${CONFIG.THEME.neon_orange}; }
        .status-error { background: ${CONFIG.THEME.error}10; color: ${CONFIG.THEME.error}; }
        
        /* Barra de progresso neon */
        .neon-progress {
          width: 100%;
          height: 8px;
          background: ${CONFIG.THEME.secondary};
          border-radius: 4px;
          margin: 10px 0;
          overflow: hidden;
          position: relative;
        }
        
        .neon-progress-bar {
          height: 100%;
          background: linear-gradient(90deg, ${CONFIG.THEME.neon_cyan}, ${CONFIG.THEME.neon_purple});
          transition: width 0.5s ease;
          position: relative;
        }
        
        .neon-progress-bar::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(90deg, transparent 40%, ${CONFIG.THEME.text_primary}60 50%, transparent 60%);
          animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        
        /* Stats grid */
        .stats-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          margin: 15px 0;
        }
        
        .stat-item {
          background: ${CONFIG.THEME.glass};
          padding: 10px;
          border-radius: 6px;
          text-align: center;
          border: 1px solid ${CONFIG.THEME.accent}40;
        }
        
        .stat-label {
          font-size: 10px;
          color: ${CONFIG.THEME.text_secondary};
          margin-bottom: 5px;
          text-transform: uppercase;
          letter-spacing: 1px;
        }
        
        .stat-value {
          font-size: 14px;
          font-weight: 700;
          color: ${CONFIG.THEME.neon_cyan};
        }
        
        /* Fila de imagens */
        .image-queue {
          max-height: 200px;
          overflow-y: auto;
        }
        
        .queue-item {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 8px;
          margin: 5px 0;
          background: ${CONFIG.THEME.glass};
          border-radius: 6px;
          border: 1px solid ${CONFIG.THEME.accent}40;
          transition: all 0.3s;
        }
        
        .queue-item:hover {
          border-color: ${CONFIG.THEME.neon_cyan}60;
          background: ${CONFIG.THEME.neon_cyan}10;
        }
        
        .queue-item.current {
          border-color: ${CONFIG.THEME.neon_green};
          background: ${CONFIG.THEME.neon_green}10;
        }
        
        .queue-thumbnail {
          width: 40px;
          height: 40px;
          border-radius: 4px;
          border: 1px solid ${CONFIG.THEME.accent};
        }
        
        .queue-info {
          flex: 1;
        }
        
        .queue-name {
          font-size: 12px;
          font-weight: 600;
          color: ${CONFIG.THEME.text_primary};
          margin-bottom: 2px;
        }
        
        .queue-details {
          font-size: 10px;
          color: ${CONFIG.THEME.text_secondary};
        }
        
        /* Configurações */
        .setting-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 8px 0;
          border-bottom: 1px solid ${CONFIG.THEME.accent}20;
        }
        
        .setting-label {
          font-size: 12px;
          color: ${CONFIG.THEME.text_primary};
        }
        
        .neon-switch {
          position: relative;
          width: 40px;
          height: 20px;
          background: ${CONFIG.THEME.secondary};
          border-radius: 10px;
          border: 1px solid ${CONFIG.THEME.accent};
          cursor: pointer;
          transition: all 0.3s;
        }
        
        .neon-switch::after {
          content: '';
          position: absolute;
          top: 2px;
          left: 2px;
          width: 14px;
          height: 14px;
          background: ${CONFIG.THEME.text_secondary};
          border-radius: 50%;
          transition: all 0.3s;
        }
        
        .neon-switch.active {
          background: ${CONFIG.THEME.neon_cyan}40;
          border-color: ${CONFIG.THEME.neon_cyan};
        }
        
        .neon-switch.active::after {
          transform: translateX(20px);
          background: ${CONFIG.THEME.neon_cyan};
        }
        
        /* Scrollbar personalizada */
        .painter-content::-webkit-scrollbar {
          width: 6px;
        }
        
        .painter-content::-webkit-scrollbar-track {
          background: ${CONFIG.THEME.secondary};
        }
        
        .painter-content::-webkit-scrollbar-thumb {
          background: ${CONFIG.THEME.neon_cyan}60;
          border-radius: 3px;
        }
        
        .painter-content::-webkit-scrollbar-thumb:hover {
          background: ${CONFIG.THEME.neon_cyan};
        }
        
        /* Minimizado */
        .painter-minimized .painter-nav,
        .painter-minimized .painter-content {
          display: none;
        }
      `;
      
      document.head.appendChild(style);
    }
    
    createMainContainer() {
      const container = document.createElement('div');
      container.id = 'wplace-auto-painter-v2';
      
      container.innerHTML = `
        <div class="painter-header">
          <div class="painter-title">
            <h1>${Utils.t('title')}</h1>
            <div class="painter-subtitle">${Utils.t('subtitle')}</div>
          </div>
          <div class="header-controls">
            <button class="header-btn" id="minimizeBtn" title="Minimizar">
              <i class="fas fa-minus"></i>
            </button>
            <button class="header-btn" id="settingsBtn" title="Configurações">
              <i class="fas fa-cog"></i>
            </button>
          </div>
        </div>
        
        <div class="painter-nav">
          <button class="nav-tab active" data-panel="control">
            <i class="fas fa-play"></i> CONTROLE
          </button>
          <button class="nav-tab" data-panel="queue">
            <i class="fas fa-images"></i> FILA
          </button>
          <button class="nav-tab" data-panel="stats">
            <i class="fas fa-chart-line"></i> STATS
          </button>
          <button class="nav-tab" data-panel="advanced">
            <i class="fas fa-cogs"></i> AVANÇADO
          </button>
        </div>
        
        <div class="painter-content">
          <!-- Control Panel -->
          <div class="content-panel active" id="control-panel">
            <button class="neon-btn primary" id="initSystemBtn">
              <i class="fas fa-power-off"></i>
              <span>${Utils.t('initBot')}</span>
            </button>
            
            <button class="neon-btn purple" id="uploadImagesBtn" disabled>
              <i class="fas fa-images"></i>
              <span>${Utils.t('uploadImages')}</span>
            </button>
            
            <button class="neon-btn warning" id="selectPositionBtn" disabled>
              <i class="fas fa-crosshairs"></i>
              <span>DEFINIR POSIÇÃO</span>
            </button>
            
            <div class="neon-card glow">
              <div class="neon-progress">
                <div class="neon-progress-bar" id="mainProgressBar" style="width: 0%"></div>
              </div>
              
              <div class="stats-grid">
                <div class="stat-item">
                  <div class="stat-label">PROJETO</div>
                  <div class="stat-value" id="currentProjectStat">-</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">PROGRESSO</div>
                  <div class="stat-value" id="progressStat">0%</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">CARGAS</div>
                  <div class="stat-value" id="chargesStat">0</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">TEMPO</div>
                  <div class="stat-value" id="timeStat">-</div>
                </div>
              </div>
            </div>
            
            <button class="neon-btn success" id="startProjectBtn" disabled>
              <i class="fas fa-rocket"></i>
              <span>${Utils.t('startProject')}</span>
            </button>
            
            <div style="display: flex; gap: 10px;">
              <button class="neon-btn warning" id="pauseProjectBtn" disabled style="flex: 1;">
                <i class="fas fa-pause"></i>
                <span>PAUSAR</span>
              </button>
              <button class="neon-btn danger" id="stopProjectBtn" disabled style="flex: 1;">
                <i class="fas fa-stop"></i>
                <span>PARAR</span>
              </button>
            </div>
            
            <div class="status-display status-ready" id="mainStatus">
              ${Utils.t('systemReady')}
            </div>
          </div>
          
          <!-- Queue Panel -->
          <div class="content-panel" id="queue-panel">
            <div class="neon-card">
              <h3 style="margin-top: 0; color: ${CONFIG.THEME.neon_purple};">
                <i class="fas fa-list"></i> FILA DE IMAGENS
              </h3>
              <div class="image-queue" id="imageQueueList">
                <div style="text-align: center; color: ${CONFIG.THEME.text_secondary}; padding: 20px;">
                  Nenhuma imagem na fila
                </div>
              </div>
            </div>
            
            <button class="neon-btn purple" id="addImagesBtn">
              <i class="fas fa-plus"></i>
              <span>ADICIONAR IMAGENS</span>
            </button>
            
            <button class="neon-btn warning" id="clearQueueBtn">
              <i class="fas fa-trash"></i>
              <span>LIMPAR FILA</span>
            </button>
          </div>
          
          <!-- Stats Panel -->
          <div class="content-panel" id="stats-panel">
            <div class="neon-card">
              <h3 style="margin-top: 0; color: ${CONFIG.THEME.neon_green};">
                <i class="fas fa-chart-bar"></i> ESTATÍSTICAS DETALHADAS
              </h3>
              
              <div class="stats-grid">
                <div class="stat-item">
                  <div class="stat-label">PIXELS TOTAL</div>
                  <div class="stat-value" id="totalPixelsStat">0</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">PIXELS PINTADOS</div>
                  <div class="stat-value" id="paintedPixelsStat">0</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">PIXELS/MIN</div>
                  <div class="stat-value" id="pixelsPerMinStat">0</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">EFICIÊNCIA</div>
                  <div class="stat-value" id="efficiencyStat">0%</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">TEMPO ATIVO</div>
                  <div class="stat-value" id="uptimeStat">0s</div>
                </div>
                <div class="stat-item">
                  <div class="stat-label">ERROS</div>
                  <div class="stat-value" id="errorsStat">0</div>
                </div>
              </div>
            </div>
            
            <div class="neon-card" id="colorStatsCard">
              <h4 style="margin-top: 0; color: ${CONFIG.THEME.neon_cyan};">
                <i class="fas fa-palette"></i> CORES MAIS USADAS
              </h4>
              <div id="colorStatsList">
                <div style="text-align: center; color: ${CONFIG.THEME.text_secondary};">
                  Nenhum dado disponível
                </div>
              </div>
            </div>
          </div>
          
          <!-- Advanced Panel -->
          <div class="content-panel" id="advanced-panel">
            <div class="neon-card">
              <h3 style="margin-top: 0; color: ${CONFIG.THEME.neon_orange};">
                <i class="fas fa-sliders-h"></i> CONFIGURAÇÕES AVANÇADAS
              </h3>
              
              <div class="setting-item">
                <span class="setting-label">${Utils.t('autoMode')}</span>
                <div class="neon-switch active" data-setting="autoMode"></div>
              </div>
              
              <div class="setting-item">
                <span class="setting-label">${Utils.t('smartQueue')}</span>
                <div class="neon-switch active" data-setting="smartQueue"></div>
              </div>
              
              <div class="setting-item">
                <span class="setting-label">${Utils.t('autoRestart')}</span>
                <div class="neon-switch" data-setting="autoRestart"></div>
              </div>
              
              <div class="setting-item">
                <span class="setting-label">${Utils.t('lowLatency')}</span>
                <div class="neon-switch" data-setting="lowLatency"></div>
              </div>
              
              <div class="setting-item">
                <span class="setting-label">${Utils.t('colorOptimization')}</span>
                <div class="neon-switch active" data-setting="colorOptimization"></div>
              </div>
              
              <div class="setting-item">
                <span class="setting-label">${Utils.t('performanceMode')}</span>
                <div class="neon-switch" data-setting="performanceMode"></div>
              </div>
            </div>
            
            <div class="neon-card">
              <h4 style="margin-top: 0; color: ${CONFIG.THEME.neon_purple};">
                <i class="fas fa-save"></i> GERENCIAMENTO
              </h4>
              
              <button class="neon-btn success" id="saveProgressBtn">
                <i class="fas fa-download"></i>
                <span>${Utils.t('saveProgress')}</span>
              </button>
              
              <button class="neon-btn warning" id="loadProgressBtn">
                <i class="fas fa-upload"></i>
                <span>${Utils.t('loadProgress')}</span>
              </button>
              
              <button class="neon-btn danger" id="resetAllBtn">
                <i class="fas fa-trash-alt"></i>
                <span>RESET COMPLETO</span>
              </button>
            </div>
          </div>
        </div>
      `;
      
      document.body.appendChild(container);
      this.container = container;
      
      // Adiciona funcionalidade de arrastar
      this.makeDraggable();
    }
    
    createPanels() {
      this.panels = {
        control: document.getElementById('control-panel'),
        queue: document.getElementById('queue-panel'),
        stats: document.getElementById('stats-panel'),
        advanced: document.getElementById('advanced-panel')
      };
    }
    
    bindEvents() {
      // Navegação por tabs
      document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.addEventListener('click', () => {
          const panelId = tab.dataset.panel;
          this.showPanel(panelId);
        });
      });
      
      // Controles do header
      document.getElementById('minimizeBtn').addEventListener('click', () => {
        this.container.classList.toggle('painter-minimized');
      });
      
      // Controles principais
      document.getElementById('initSystemBtn').addEventListener('click', () => this.initSystem());
      document.getElementById('uploadImagesBtn').addEventListener('click', () => this.uploadImages());
      document.getElementById('selectPositionBtn').addEventListener('click', () => this.selectPosition());
      document.getElementById('startProjectBtn').addEventListener('click', () => this.startProject());
      document.getElementById('pauseProjectBtn').addEventListener('click', () => this.pauseProject());
      document.getElementById('stopProjectBtn').addEventListener('click', () => this.stopProject());
      
      // Controles da fila
      document.getElementById('addImagesBtn').addEventListener('click', () => this.uploadImages());
      document.getElementById('clearQueueBtn').addEventListener('click', () => this.clearQueue());
      
      // Configurações
      document.querySelectorAll('.neon-switch').forEach(toggle => {
        toggle.addEventListener('click', () => {
          const setting = toggle.dataset.setting;
          state.settings[setting] = !state.settings[setting];
          toggle.classList.toggle('active', state.settings[setting]);
        });
      });
      
      // Gerenciamento
      document.getElementById('saveProgressBtn').addEventListener('click', () => Utils.saveProgress());
      document.getElementById('loadProgressBtn').addEventListener('click', () => {
        if (Utils.loadProgress()) {
          Utils.showToast('Progresso carregado com sucesso!', 'success');
          this.updateAllStats();
        } else {
          Utils.showToast('Nenhum progresso salvo encontrado', 'warning');
        }
      });
      
      document.getElementById('resetAllBtn').addEventListener('click', () => {
        if (confirm('Tem certeza que deseja resetar tudo?')) {
          localStorage.removeItem('wplace_auto_painter_v2');
          location.reload();
        }
      });
    }
    
    makeDraggable() {
      const header = this.container.querySelector('.painter-header');
      let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
      
      header.onmousedown = (e) => {
        if (e.target.closest('.header-controls')) return;
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
      };
      
      const elementDrag = (e) => {
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        this.container.style.top = (this.container.offsetTop - pos2) + "px";
        this.container.style.left = (this.container.offsetLeft - pos1) + "px";
      };
      
      const closeDragElement = () => {
        document.onmouseup = null;
        document.onmousemove = null;
      };
    }
    
    showPanel(panelId) {
      // Atualiza tabs
      document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
      });
      document.querySelector(`[data-panel="${panelId}"]`).classList.add('active');
      
      // Atualiza painéis
      Object.values(this.panels).forEach(panel => {
        panel.classList.remove('active');
      });
      this.panels[panelId].classList.add('active');
    }
    
    async initSystem() {
      try {
        this.updateStatus('Inicializando sistema...', 'working');
        
        // Detecta cores disponíveis
        state.availableColors = Utils.extractAvailableColors();
        
        if (state.availableColors.length === 0) {
          this.updateStatus('❌ Paleta não encontrada! Abra as cores no site', 'error');
          Utils.showToast(Utils.t('noColorsFound'), 'error');
          return;
        }
        
        state.initialized = true;
        
        // Habilita controles
        document.getElementById('uploadImagesBtn').disabled = false;
        document.getElementById('selectPositionBtn').disabled = false;
        document.getElementById('initSystemBtn').style.display = 'none';
        
        this.updateStatus(Utils.t('colorsFound', { count: state.availableColors.length }), 'ready');
        Utils.showToast('Sistema inicializado com sucesso!', 'success');
        
        this.updateAllStats();
        
      } catch (error) {
        this.updateStatus('❌ Erro na inicialização', 'error');
        Utils.showToast('Erro ao inicializar sistema', 'error');
      }
    }
    
    async uploadImages() {
      try {
        const imageFiles = await Utils.createMultiImageUploader();
        
        for (const file of imageFiles) {
          const processor = new ImageProcessor(file);
          await processor.load();
          
          const imageData = {
            id: file.id,
            name: file.name,
            size: file.size,
            processor,
            dimensions: processor.getDimensions(),
            validPixels: processor.getValidPixelsCount(),
            thumbnail: processor.generateThumbnail(),
            status: 'pending'
          };
          
          state.imageQueue.push(imageData);
        }
        
        this.updateQueue();
        this.updateAllStats();
        
        Utils.showToast(Utils.t('imagesLoaded', { count: imageFiles.length }), 'success');
        
        if (state.startPosition && state.imageQueue.length > 0) {
          document.getElementById('startProjectBtn').disabled = false;
        }
        
      } catch (error) {
        Utils.showToast('Erro ao carregar imagens', 'error');
      }
    }
    
    async selectPosition() {
      if (state.selectingPosition) return;
      
      state.selectingPosition = true;
      state.startPosition = null;
      state.region = null;
      
      this.updateStatus(Utils.t('selectPosition'), 'working');
      Utils.showToast(Utils.t('selectPosition'), 'info');
      
      const originalFetch = window.fetch;
      
      window.fetch = async (url, options) => {
        if (typeof url === 'string' && 
            url.includes('https://backend.wplace.live/s0/pixel/') && 
            options?.method?.toUpperCase() === 'POST') {
          
          try {
            const response = await originalFetch(url, options);
            const clonedResponse = response.clone();
            const data = await clonedResponse.json();
            
            if (data?.painted === 1) {
              const regionMatch = url.match(/\/pixel\/(\d+)\/(\d+)/);
              if (regionMatch && regionMatch.length >= 3) {
                state.region = {
                  x: parseInt(regionMatch[1]),
                  y: parseInt(regionMatch[2])
                };
              }
              
              const payload = JSON.parse(options.body);
              if (payload?.coords && Array.isArray(payload.coords)) {
                state.startPosition = {
                  x: payload.coords[0],
                  y: payload.coords[1]
                };
                
                window.fetch = originalFetch;
                state.selectingPosition = false;
                
                this.updateStatus(Utils.t('positionSet'), 'ready');
                Utils.showToast(Utils.t('positionSet'), 'success');
                
                if (state.imageQueue.length > 0) {
                  document.getElementById('startProjectBtn').disabled = false;
                }
              }
            }
            
            return response;
          } catch {
            return originalFetch(url, options);
          }
        }
        return originalFetch(url, options);
      };
      
      // Timeout para seleção de posição
      setTimeout(() => {
        if (state.selectingPosition) {
          window.fetch = originalFetch;
          state.selectingPosition = false;
          this.updateStatus('❌ Tempo esgotado para seleção', 'error');
          Utils.showToast('Tempo esgotado para seleção de posição', 'error');
        }
      }, 120000);
    }
    
    async startProject() {
      if (!state.initialized || !state.startPosition || state.imageQueue.length === 0) {
        Utils.showToast('Configure o sistema primeiro!', 'warning');
        return;
      }
      
      state.running = true;
      state.paused = false;
      state.stats.startTime = Date.now();
      
      // Atualiza UI
      document.getElementById('startProjectBtn').disabled = true;
      document.getElementById('pauseProjectBtn').disabled = false;
      document.getElementById('stopProjectBtn').disabled = false;
      
      this.updateStatus(Utils.t('projectStarted'), 'working');
      Utils.showToast('Projeto iniciado!', 'success');
      
      // Inicia processamento
      this.startPaintingLoop();
    }
    
    pauseProject() {
      if (!state.running) return;
      
      state.paused = !state.paused;
      const pauseBtn = document.getElementById('pauseProjectBtn');
      
      if (state.paused) {
        pauseBtn.innerHTML = '<i class="fas fa-play"></i><span>RETOMAR</span>';
        this.updateStatus('⏸️ Projeto pausado', 'paused');
        Utils.showToast('Projeto pausado', 'warning');
      } else {
        pauseBtn.innerHTML = '<i class="fas fa-pause"></i><span>PAUSAR</span>';
        this.updateStatus('🎨 Projeto retomado', 'working');
        Utils.showToast('Projeto retomado', 'success');
      }
    }
    
    stopProject() {
      if (!state.running) return;
      
      state.running = false;
      state.paused = false;
      
      // Atualiza UI
      document.getElementById('startProjectBtn').disabled = false;
      document.getElementById('pauseProjectBtn').disabled = true;
      document.getElementById('stopProjectBtn').disabled = true;
      document.getElementById('pauseProjectBtn').innerHTML = '<i class="fas fa-pause"></i><span>PAUSAR</span>';
      
      this.updateStatus(Utils.t('projectStopped'), 'ready');
      Utils.showToast('Projeto interrompido', 'warning');
    }
    
    clearQueue() {
      if (confirm('Tem certeza que deseja limpar a fila?')) {
        state.imageQueue = [];
        state.currentImageIndex = 0;
        this.updateQueue();
        document.getElementById('startProjectBtn').disabled = true;
        Utils.showToast('Fila limpa', 'success');
      }
    }
    
    updateQueue() {
      const queueList = document.getElementById('imageQueueList');
      
      if (state.imageQueue.length === 0) {
        queueList.innerHTML = `
          <div style="text-align: center; color: ${CONFIG.THEME.text_secondary}; padding: 20px;">
            Nenhuma imagem na fila
          </div>
        `;
        return;
      }
      
      queueList.innerHTML = state.imageQueue.map((item, index) => `
        <div class="queue-item ${index === state.currentImageIndex ? 'current' : ''}">
          <img src="${item.thumbnail}" alt="${item.name}" class="queue-thumbnail">
          <div class="queue-info">
            <div class="queue-name">${item.name}</div>
            <div class="queue-details">
              ${item.dimensions.width}x${item.dimensions.height} • 
              ${item.validPixels} pixels • 
              ${item.status}
            </div>
          </div>
          <div style="color: ${index === state.currentImageIndex ? CONFIG.THEME.neon_green : CONFIG.THEME.text_secondary};">
            ${index === state.currentImageIndex ? '▶️' : `#${index + 1}`}
          </div>
        </div>
      `).join('');
    }
    
    updateStatus(message, type = 'ready') {
      const statusEl = document.getElementById('mainStatus');
      statusEl.textContent = message;
      statusEl.className = `status-display status-${type}`;
    }
    
    updateAllStats() {
      // Stats principais
      document.getElementById('currentProjectStat').textContent = 
        state.imageQueue.length > 0 ? state.imageQueue[state.currentImageIndex]?.name || '-' : '-';
      
      const totalPixels = state.imageQueue.reduce((sum, img) => sum + img.validPixels, 0);
      const paintedPixels = state.stats.totalPixelsPainted;
      const progress = totalPixels > 0 ? Math.round((paintedPixels / totalPixels) * 100) : 0;
      
      document.getElementById('progressStat').textContent = `${progress}%`;
      document.getElementById('chargesStat').textContent = state.charges;
      document.getElementById('timeStat').textContent = 
        state.stats.startTime ? Utils.formatTime(Date.now() - state.stats.startTime) : '-';
      
      // Barra de progresso
      document.getElementById('mainProgressBar').style.width = `${progress}%`;
      
      // Stats detalhadas
      document.getElementById('totalPixelsStat').textContent = totalPixels.toLocaleString();
      document.getElementById('paintedPixelsStat').textContent = paintedPixels.toLocaleString();
      document.getElementById('pixelsPerMinStat').textContent = Math.round(state.stats.averagePixelsPerMinute);
      document.getElementById('efficiencyStat').textContent = `${Math.round(state.stats.efficiency)}%`;
      document.getElementById('uptimeStat').textContent = 
        state.stats.startTime ? Utils.formatTime(Date.now() - state.stats.startTime) : '0s';
      document.getElementById('errorsStat').textContent = state.stats.errors;
      
      // Stats de cores
      this.updateColorStats();
    }
    
    updateColorStats() {
      const colorStatsList = document.getElementById('colorStatsList');
      
      if (state.colorStats.size === 0) {
        colorStatsList.innerHTML = `
          <div style="text-align: center; color: ${CONFIG.THEME.text_secondary};">
            Nenhum dado disponível
          </div>
        `;
        return;
      }
      
      const sortedColors = Array.from(state.colorStats.entries())
        .sort((a, b) => b[1].used - a[1].used)
        .slice(0, 5);
      
      colorStatsList.innerHTML = sortedColors.map(([colorId, data]) => `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 16px; height: 16px; background: ${data.hex}; border-radius: 2px; border: 1px solid ${CONFIG.THEME.accent};"></div>
            <span style="font-size: 12px;">${data.hex}</span>
          </div>
          <span style="font-size: 12px; color: ${CONFIG.THEME.neon_cyan};">${data.used}</span>
        </div>
      `).join('');
    }
    
    async startPaintingLoop() {
      while (state.running && state.currentImageIndex < state.imageQueue.length) {
        if (state.paused) {
          await Utils.sleep(1000);
          continue;
        }
        
        const currentImage = state.imageQueue[state.currentImageIndex];
        if (!currentImage) break;
        
        currentImage.status = 'painting';
        this.updateQueue();
        
        try {
          await this.paintImage(currentImage);
          currentImage.status = 'completed';
          state.currentImageIndex++;
        } catch (error) {
          currentImage.status = 'error';
          state.stats.errors++;
          Utils.showToast(`Erro ao pintar ${currentImage.name}`, 'error');
          
          if (state.settings.autoRestart) {
            await Utils.sleep(5000);
            continue;
          } else {
            break;
          }
        }
        
        this.updateQueue();
        this.updateAllStats();
        
        // Auto-save
        if (state.settings.autoSave && Date.now() - state.lastSave > CONFIG.AUTO_SAVE_INTERVAL) {
          Utils.saveProgress();
          state.lastSave = Date.now();
        }
      }
      
      // Projeto finalizado
      if (state.running) {
        this.updateStatus(Utils.t('projectCompleted', { pixels: state.stats.totalPixelsPainted }), 'ready');
        Utils.showToast('Projeto finalizado!', 'success');
        this.stopProject();
      }
    }
    
    async paintImage(imageData) {
      const { processor } = imageData;
      const { validPixels } = processor;
      
      for (let i = 0; i < validPixels.length; i++) {
        if (!state.running || state.paused) break;
        
        const pixel = validPixels[i];
        
        // Verifica cargas
        if (state.charges < 1) {
          const chargeData = await WPlaceService.getCharges();
          state.charges = chargeData.charges;
          state.cooldown = chargeData.cooldown;
          
          if (state.charges < 1) {
            this.updateStatus(`⌛ Aguardando cargas... ${Utils.formatTime(state.cooldown)}`, 'working');
            await Utils.sleep(state.cooldown);
            continue;
          }
        }
        
        // Calcula cor mais próxima
        if (!pixel.colorId && state.settings.colorOptimization) {
          let closestColor = state.availableColors[0];
          let minDistance = Utils.colorDistance(pixel.rgb, closestColor.rgb);
          
          for (const color of state.availableColors) {
            const distance = Utils.colorDistance(pixel.rgb, color.rgb);
            if (distance < minDistance) {
              minDistance = distance;
              closestColor = color;
            }
          }
          
          pixel.colorId = closestColor.id;
        }
        
        // Pinta pixel
        const success = await WPlaceService.paintPixelInRegion(
          state.region.x,
          state.region.y,
          state.startPosition.x + pixel.x,
          state.startPosition.y + pixel.y,
          pixel.colorId
        );
        
        if (success) {
          state.charges--;
          state.stats.totalPixelsPainted++;
          
          // Atualiza estatísticas
          if (state.stats.startTime) {
            const elapsed = Date.now() - state.stats.startTime;
            state.stats.averagePixelsPerMinute = (state.stats.totalPixelsPainted / elapsed) * 60000;
            state.stats.efficiency = Math.min(100, (state.stats.totalPixelsPainted / (state.stats.totalPixelsPainted + state.stats.errors)) * 100);
          }
        } else {
          state.stats.errors++;
        }
        
        // Delay entre pixels
        if (state.settings.pixelDelay > 0) {
          await Utils.sleep(state.settings.pixelDelay);
        }
        
        // Atualiza UI periodicamente
        if (i % CONFIG.LOG_INTERVAL === 0) {
          this.updateAllStats();
        }
      }
    }
    
    startAnimationLoop() {
      setInterval(() => {
        if (state.running) {
          this.updateAllStats();
        }
      }, 1000);
    }
  }

  // Inicialização principal
  async function initialize() {
    try {
      // Detecta idioma
      state.language = Utils.detectLanguage();
      
      // Carrega progresso salvo se disponível
      Utils.loadProgress();
      
      // Inicializa UI
      const ui = new UIManager();
      await ui.initialize();
      
      // Adiciona ícones do Font Awesome
      if (!document.querySelector('link[href*="font-awesome"]')) {
        const fontAwesome = document.createElement('link');
        fontAwesome.rel = 'stylesheet';
        fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
        document.head.appendChild(fontAwesome);
      }
      
      console.log(`%c🚀 WPlace Auto Painter V${CONFIG.VERSION} - NEON EDITION 🚀`, 
        'background: linear-gradient(45deg, #00ffff, #ff00ff); color: white; padding: 10px; font-weight: bold;');
      
    } catch (error) {
      console.error('❌ Erro na inicialização:', error);
      Utils.showToast('Erro crítico na inicialização!', 'error');
    }
  }

  // Inicia o sistema
  initialize();

})();

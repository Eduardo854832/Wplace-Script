# Tutorial: Como usar o Wplace-AutoFarm

**Atenção:** Sempre copie o script diretamente do repositório oficial!

## Passo a passo

1. Abra o Google Chrome.
2. Clique nos três pontinhos no canto superior direito do navegador.
3. Adicione qualquer página aos favoritos (pode ser a atual).
4. Clique na mensagem de confirmação do favorito.
5. Renomeie o favorito (exemplo: wplace).
6. Apague o campo URL do favorito.
7. Cole o script copiado do repositório oficial.
8. Salve clicando na seta de voltar.
9. Acesse o site [wplace.live](https://wplace.live).
10. Digite o nome do favorito na barra de endereços.
11. Clique no favorito para ativar o script.

**Pronto! O script estará ativo! 🚀**

---
Dúvidas? Veja o README.md ou abra uma issue.
